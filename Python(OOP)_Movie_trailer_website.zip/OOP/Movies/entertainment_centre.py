#Stores details of movies and displays them on website.
import fresh_tomatoes
import media
#Creates five Movie objects and initialising thes objects.
toy_story = media.Movie("Toy Story",
                        "A story of a boy an his toys that comes to his life",
                        "http://upload.wikimedia.org/wikipedia/en/1/13/\
                        Toy-Story.jpg",
                        "https://www.youtube.com/watch?v=KYz2wyBy3kc")
avatar = media.Movie("Avatar", "A marine on an alien planet",
                     "http://upload.wikimedia.org/wikipedia/en/1/13/\
                     Toy-Story.jpg"
                     "https://www.youtube.com/watch?v=-9ceBgWV8io")
peter_pan = media.Movie("Peter Pan", "A free-spirited and mischievous young boy\
                        who can fly ",
                        "https://vignette.wikia.nocookie.net/disney/images/d/\
                        d5/Peter_Pan_-_Poster.png/revision/latest?cb=\
                        20140902164811",
                        "https://www.youtube.com/watch?v=5K83Ix1R9Mc&pbjreload=\
                        10")
ratatouille = media.Movie("Ratatouille", "A rat is a chef in Paris",
                          "https://vignette.wikia.nocookie.net/disney/images/c/\
                          c8/Ratatouille_poster.jpg/revision/latest?cb=\
                          20130328084644",
                          "https://www.youtube.com/watch?v=e8GBfNo3IHY")
incredible = media.Movie("Incredible", "The Real Super Heroes",
                         "https://vignette.wikia.nocookie.net/disney/\
                        images/0/00/Incredibles_2_-_Poster.jpg/revision/\
                        latest?cb=20180530102812",
                         "https://www.youtube.com/watch?v=i5qOzqD9Rms")
#Stores the Movie objects in a list.
movies = [toy_story, avatar, peter_pan, ratatouille, incredible]
#Open the movie website in the user's browser, featuring the movies above
fresh_tomatoes.open_movies_page(movies)
