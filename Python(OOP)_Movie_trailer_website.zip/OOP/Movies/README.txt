WHAT IT IS AND DOES:
A python program that produces  the HTML for a movie website 
that displays a number of movies trailer by just clicking on the
poster image.

REQUIRED LIBRARIES AND DEPENDENCIES:
Python 3.6 is required to run this project. The Python executable 
should be in your default path, which the python installer
should have set.

PROJECT CONTENT:
This project consists for the following files:
#entertainment_centre.py - main python script to run
#media.py - contains the class movie that stores
movie details.
#fresh_tomatoes.py - creates the HTML file for the website

HOW TO RUN PROJECT:
Download the project zip file to you computer and unzip the
file. 
Open the text based interface for your operating system.


