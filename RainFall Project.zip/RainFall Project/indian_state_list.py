#!/usr/bin/env python
# coding: utf-8

d_state = {'rajasthan': 0, 'madhya pradesh': 1, 'maharashtra': 2, 'jammu & kashmir': 3, 'uttar pradesh': 4, 'andhra pradesh': 5, 'gujarat': 6, 'karnataka': 7, 'orissa': 8, 'chhattisgarh': 9, 'tamil nadu': 10, 'bihar': 11, 'arunachal pradesh': 12, 'assam': 13, 'jharkhand': 14, 'west bengal': 15, 'himachal pradesh': 16, 'uttarakhand': 17, 'punjab': 18, 'haryana': 19, 'kerala': 20, 'manipur': 21, 'meghalaya': 22, 'mizoram': 23, 'nagaland': 24, 'tripura': 25, 'sikkim': 26, 'goa': 27, 'delhi': 28}
